# Indian 14-Bank Power BI Star Schema Dataset — Data Dictionary & DAX Guide

## 1. Table Inventory & Row Counts (304,830 Total Rows)
1. **Dim_Banks.csv** (14 rows): 14 real Indian Public & Private Sector Banks (State Bank of India, HDFC Bank, ICICI Bank, Punjab National Bank, Axis Bank, Bank of Baroda, Kotak Mahindra Bank, Canara Bank, Union Bank of India, IndusInd Bank, Indian Bank, IDFC FIRST Bank, Federal Bank, Yes Bank) with HQ city/state, established year, IFSC/MICR/BSR codes, core banking focus, and synthetic benchmark rates.
2. **Dim_Branches.csv** (420 rows): 30 branches per bank across all 6 Indian Geographic Zones (North, South, East, West, Central, North-East), complete with Street Address, Locality/Area, City, District, State/UT, 6-digit PIN Code, Latitude & Longitude, IFSC, 9-digit MICR, 7-digit BSR Code, RBI Population Group (`Metropolitan`, `Urban`, `Semi-Urban`, `Rural`), RBI Centre Tier (`Tier-1` to `Tier-5`), Onsite ATM counts, and Monthly Operating Expense (INR).
3. **Dim_Employees.csv** (6,300 rows): 15 staff per branch across 6 banking designations (`Branch Manager`, `Senior Relationship Manager`, `Credit & Loan Officer`, `Operations & Compliance Officer`, `Customer Service Executive`, `Digital Banking Specialist`) with joining dates, experience, annual CTC (INR), appraisal ratings, and target achievement %.
4. **Dim_Customers.csv** (28,000 rows): Retail & MSME customers across all 14 banks with CIBIL Credit Score, Credit Risk Category, Age Group, Indian Annual Income Range, CKYC status, and full residential location (`Customer_City`, `Customer_District`, `Customer_State`, `Customer_Zone`, `Customer_PIN_Code`, `Urban_Rural_Segment`).
5. **Dim_Accounts.csv** (45,000 rows): Multi-bank deposit accounts (`Savings`, `Salary`, `Current`, `Fixed Deposit (FD)`, `Recurring Deposit (RD)`, `NRI / NRE`) with masked account numbers, interest rates, and INR balances.
6. **Dim_Date.csv** (1,096 rows): Complete daily calendar (`2024-01-01` to `2026-12-31`) with `Indian_Financial_Year` (`FY 2023-24` to `FY 2026-27`) and `Indian_Financial_Quarter` (`Q1 (Apr-Jun)` to `Q4 (Jan-Mar)`).
7. **Fact_Transactions.csv** (180,000 rows): Payment ledger across `UPI`, `IMPS / NEFT`, `RTGS`, `Debit Card / POS`, `ATM Cash Withdrawal`, `Auto-Debit / NACH`, and `Branch Teller`, including `Transaction_Hour`, `Transaction_Location_Type` (Home City vs. Outstation), and `Suspicious_Fraud_Alert`.
8. **Fact_Loans.csv** (28,000 rows): Home, Personal, Auto, MSME/Mudra, Gold, and Education loans linked to `Sanctioning_Loan_Officer_ID` with EMI, APR %, Days Past Due, and `RBI_Asset_Classification` (`Standard`, `SMA-1`, `SMA-2`, `NPA Sub-Standard`).
9. **Fact_Credit_Cards.csv** (16,000 rows): Credit card portfolio (`RuPay Platinum`, `Visa Signature`, `Mastercard World`, `Co-Branded Travel`, `Super-Premium Metal`) with credit limits, utilization ratios, monthly spend, and reward points.

## 2. Recommended Power BI Data Model Relationships
- `Dim_Banks[Bank_ID]` (1) -> `Dim_Branches[Bank_ID]` (*)
- `Dim_Banks[Bank_ID]` (1) -> `Dim_Employees[Bank_ID]` (*)
- `Dim_Banks[Bank_ID]` (1) -> `Dim_Accounts[Bank_ID]` (*)
- `Dim_Banks[Bank_ID]` (1) -> `Fact_Transactions[Bank_ID]` (*)
- `Dim_Banks[Bank_ID]` (1) -> `Fact_Loans[Bank_ID]` (*)
- `Dim_Banks[Bank_ID]` (1) -> `Fact_Credit_Cards[Bank_ID]` (*)
- `Dim_Employees[Employee_ID]` (1) -> `Fact_Loans[Sanctioning_Loan_Officer_ID]` (*)
- `Dim_Customers[Customer_ID]` (1) -> `Dim_Accounts[Customer_ID]` (*)
- `Dim_Customers[Customer_ID]` (1) -> `Fact_Loans[Customer_ID]` (*)
- `Dim_Customers[Customer_ID]` (1) -> `Fact_Credit_Cards[Customer_ID]` (*)
- `Dim_Accounts[Account_ID]` (1) -> `Fact_Transactions[Account_ID]` (*)
- `Dim_Date[Transaction_Date]` (1) -> `Fact_Transactions[Transaction_Date]` (*) [Active]
- `Dim_Date[Transaction_Date]` (1) -> `Fact_Loans[Loan_Disbursal_Date]` (*) [Inactive — activate via `USERELATIONSHIP`]
- `Dim_Date[Transaction_Date]` (1) -> `Fact_Credit_Cards[Card_Issue_Date]` (*) [Inactive — activate via `USERELATIONSHIP`]
